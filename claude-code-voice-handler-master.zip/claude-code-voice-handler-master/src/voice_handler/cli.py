#!/usr/bin/env python3
"""
CLI Entry Point - The Box Office.

Like the box office that handles all ticket requests,
this module processes command line arguments and routes
voice handler requests to the right place.
"""

import argparse
import sys
import json
from typing import Optional, Tuple, Dict, Any

# Configure UTF-8 encoding for Windows compatibility
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

from voice_handler.utils.logger import get_logger
from voice_handler.core.handler import get_handler


def read_stdin_data() -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Read and parse stdin data from Claude Code.

    Returns:
        Tuple of (parsed JSON dict or None, raw text or None)
    """
    logger = get_logger()
    stdin_data = None
    stdin_text = None

    if not sys.stdin.isatty():
        try:
            stdin_input = sys.stdin.read()
            if stdin_input:
                logger.log_debug(
                    f"Raw stdin received",
                    length=len(stdin_input),
                    first_chars=stdin_input[:200]
                )
                try:
                    stdin_data = json.loads(stdin_input)
                    logger.log_stdin_data(stdin_data)
                except json.JSONDecodeError:
                    stdin_text = stdin_input.strip()
                    logger.log_stdin_data(stdin_text)
        except Exception as e:
            logger.log_error("Error reading stdin", exception=e)
    else:
        logger.log_debug("No stdin data (terminal mode)")

    return stdin_data, stdin_text


def main():
    """
    Main entry point for voice handler CLI.

    The main stage door - all requests come through here!
    """
    parser = argparse.ArgumentParser(
        description="Claude Code Voice Handler - Natural TTS for hook events 🎸",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  voice-handler --hook UserPromptSubmit
  voice-handler --hook PreToolUse --tool Read
  voice-handler --hook Stop
  voice-handler --message "Testing, one two three!"

Hooks:
  UserPromptSubmit  - When user submits a prompt
  PreToolUse        - Before a tool is executed
  PostToolUse       - After a tool completes
  Stop              - When Claude stops processing
  Notification      - Permission/notification events
        """
    )

    parser.add_argument(
        "--voice",
        help="Voice to use (overrides session voice)"
    )
    parser.add_argument(
        "--message",
        help="Message to speak (overrides automatic generation)"
    )
    parser.add_argument(
        "--hook",
        help="Hook type (SessionStart, UserPromptSubmit, PreToolUse, PostToolUse, Stop, Notification)"
    )
    parser.add_argument(
        "--tool",
        help="Tool name (for PreToolUse hooks)"
    )
    parser.add_argument(
        "--file",
        help="File path (for file operations)"
    )
    parser.add_argument(
        "--command",
        help="Command being run (for Bash tool)"
    )
    parser.add_argument(
        "--query",
        help="Search query (for search operations)"
    )
    parser.add_argument(
        "--sync",
        action="store_true",
        help="Use synchronous mode (no background daemon)"
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging"
    )

    args = parser.parse_args()

    # Initialize logger and handler
    logger = get_logger()

    # Print status to stdout for visibility
    import os
    print(f"🎸 Voice Handler - Hook: {args.hook or 'None'}")
    print(f"   TTS: {os.getenv('TTS_PROVIDER', 'system')} | Lang: {os.getenv('LANGUAGE', 'es')} | API Key: {'✓' if os.getenv('OPENAI_API_KEY') else '✗'}")

    logger.log_info(
        "Voice handler invoked - The show begins!",
        hook=args.hook,
        tool=args.tool,
        file=args.file,
        command=args.command,
        query=args.query,
        has_message=bool(args.message)
    )

    # Determine async mode: CLI flag overrides config
    # Priority: 1) --sync flag, 2) USE_ASYNC_QUEUE from config (which reads .env), 3) default to false
    if args.sync:
        use_async = False
        logger.log_info("Using SYNC mode (from --sync flag)")
    else:
        # Read from config (which loads .env file correctly)
        from voice_handler.config import VoiceHandlerConfig
        config_obj = VoiceHandlerConfig()
        use_async = config_obj.runtime.use_async_queue
        logger.log_info(f"Using {'ASYNC' if use_async else 'SYNC'} mode (from config: USE_ASYNC_QUEUE={use_async})")

    handler = get_handler(use_async=use_async)

    # Read stdin data
    stdin_data, stdin_text = read_stdin_data()

    # Log the hook event
    logger.log_hook_event(
        args.hook,
        tool=args.tool,
        stdin_data=stdin_data or stdin_text,
        file=args.file,
        command=args.command,
        query=args.query
    )

    # Determine tool name and session ID
    tool_name = args.tool
    if stdin_data and isinstance(stdin_data, dict):
        tool_name = stdin_data.get('tool_name') or tool_name
        session_id = stdin_data.get('session_id')
        if session_id:
            handler.current_session_id = session_id
            logger.log_debug(f"Session ID captured: {session_id[:8]}...")

    # Check if this hook should trigger voice announcements
    if not handler.should_announce(args.hook, tool_name):
        print(f"   ⚠️  Hook '{args.hook}' does not trigger voice (logged only)")
        logger.log_info(f"Hook {args.hook} logged only (no voice announcement)")
        sys.exit(0)

    # Update context for voice-enabled hooks
    if args.hook:
        handler.state_manager.update_context(
            args.hook,
            tool_name=tool_name,
            file_path=args.file,
            command=args.command,
            query=args.query
        )

    # Process hook-specific logic
    message = None

    if args.hook == "SessionStart":
        message = handler.process_session_start(stdin_data)
        if not message:
            message = "Sistema listo"  # Fallback

    elif args.hook == "UserPromptSubmit":
        message = handler.process_user_prompt_submit(stdin_data)

    elif args.hook == "PreToolUse":
        message = handler.process_pre_tool_use(stdin_data, tool_name)
        if not message:
            sys.exit(0)

    elif args.hook == "PostToolUse":
        message = handler.process_post_tool_use(stdin_data)
        if not message:
            sys.exit(0)

    elif args.hook == "Stop":
        message = handler.process_stop(stdin_data)

    elif args.hook == "Notification":
        message = handler.process_notification(stdin_data)

    # Fall back to command line argument
    if not message and args.message:
        message = args.message

    # Default messages for specific hooks
    if not message:
        if args.hook == "Stop":
            message = "Listo"
        elif args.hook in ["PostToolUse", "PreToolUse"]:
            sys.exit(0)

    # Speak the message if we have one
    if message:
        logger.log_message_flow("Speaking", message)
        # Print message preview
        msg_preview = message[:60] + "..." if len(message) > 60 else message
        print(f"   ✓ Queued: {msg_preview}")
        handler.speak(message, voice=args.voice)
        print(f"   🎵 Message sent to TTS daemon")


if __name__ == "__main__":
    main()
